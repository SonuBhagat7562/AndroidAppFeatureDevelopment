package com.example.simplecalculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.androidcalculatorapp.R;

public class MainActivity extends AppCompatActivity {

    private EditText etNumber1, etNumber2;
    private RadioGroup radioGroupOperations;
    private Button btnCalculate;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        etNumber1 = findViewById(R.id.etNumber1);
        etNumber2 = findViewById(R.id.etNumber2);
        radioGroupOperations = findViewById(R.id.radioGroupOperations);
        btnCalculate = findViewById(R.id.btnCalculate);
        tvResult = findViewById(R.id.tvResult);

        // Set up the calculate button click listener
        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateResult();
            }
        });
    }

    private void calculateResult() {
        String num1Str = etNumber1.getText().toString();
        String num2Str = etNumber2.getText().toString();

        if (num1Str.isEmpty() || num2Str.isEmpty()) {
            Toast.makeText(this, "Please enter both numbers", Toast.LENGTH_SHORT).show();
            return;
        }

        double num1 = Double.parseDouble(num1Str);
        double num2 = Double.parseDouble(num2Str);

        // Get selected operation
        int selectedOperationId = radioGroupOperations.getCheckedRadioButtonId();
        if (selectedOperationId == -1) {
            Toast.makeText(this, "Please select an operation", Toast.LENGTH_SHORT).show();
            return;
        }

        double result;
        if (selectedOperationId == R.id.rbAdd) {
            result = num1 + num2;
        } else if (selectedOperationId == R.id.rbSubtract) {
            result = num1 - num2;
        } else if (selectedOperationId == R.id.rbMultiply) {
            result = num1 * num2;
        } else if (selectedOperationId == R.id.rbDivide) {
            if (num2 == 0) {
                Toast.makeText(this, "Division by zero is not allowed", Toast.LENGTH_SHORT).show();
                return;
            }
            result = num1 / num2;
        } else {
            Toast.makeText(this, "Invalid operation", Toast.LENGTH_SHORT).show();
            return;
        }

        // Display the result
        tvResult.setText("Result: " + result);
    }
}
