package com.example.calculatebodymassindex;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);  // Ensure the correct layout is set here

        // Find views by their IDs
        EditText etWeight = findViewById(R.id.etWeight);
        EditText etHeight = findViewById(R.id.etHeight);
        Button btnCalculateBMI = findViewById(R.id.btnCalculateBMI);
        TextView tvResult = findViewById(R.id.tvResult);

        // Set a click listener for the button
        btnCalculateBMI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weightStr = etWeight.getText().toString();
                String heightStr = etHeight.getText().toString();

                if (!weightStr.isEmpty() && !heightStr.isEmpty()) {
                    try {
                        float weight = Float.parseFloat(weightStr);
                        float height = Float.parseFloat(heightStr);

                        if (weight > 0 && height > 0) {
                            // Calculate BMI
                            float bmi = weight / (height * height);
                            String category;

                            if (bmi < 18.5) {
                                category = "Underweight";
                            } else if (bmi >= 18.5 && bmi <= 24.9) {
                                category = "Normal weight";
                            } else if (bmi >= 25.0 && bmi <= 29.9) {
                                category = "Overweight";
                            } else {
                                category = "Obese";
                            }

                            // Display result
                            tvResult.setText(String.format("BMI: %.2f\nCategory: %s", bmi, category));
                        } else {
                            tvResult.setText("Please enter positive values for weight and height");
                        }
                    } catch (Exception e) {
                        tvResult.setText("Invalid input. Please enter valid numbers.");
                    }
                } else {
                    tvResult.setText("Please fill in both weight and height");
                }
            }
        });
    }
}
