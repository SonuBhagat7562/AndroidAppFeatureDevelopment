package com.example.fahrenheittocelsiusconverter;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Link to your activity_main.xml

        // Find views by their IDs
        EditText etFahrenheit = findViewById(R.id.etFahrenheit);
        Button btnConvert = findViewById(R.id.btnConvert);
        TextView tvCelsius = findViewById(R.id.tvCelsius);

        // Set a click listener on the Convert button
        btnConvert.setOnClickListener(v -> {
            String fahrenheitStr = etFahrenheit.getText().toString();
            if (!fahrenheitStr.isEmpty()) {
                // Convert Fahrenheit to Celsius
                double fahrenheit = Double.parseDouble(fahrenheitStr);
                double celsius = (fahrenheit - 32) * 5 / 9;
                tvCelsius.setText(String.format("Temperature in Celsius: %.2f", celsius));
            } else {
                tvCelsius.setText("Please enter a valid temperature");
            }
        });
    }
}
