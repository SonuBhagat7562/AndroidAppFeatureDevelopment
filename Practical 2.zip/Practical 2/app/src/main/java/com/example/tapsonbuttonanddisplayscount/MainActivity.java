package com.example.tapsonbuttonanddisplayscount;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private int count = 0;  // Initialize count to 0

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);  // Ensure the correct layout is set here

        // Find views by their IDs
        Button btnTap = findViewById(R.id.btnTap);
        TextView tvCount = findViewById(R.id.tvCount);

        // Set a click listener for the button
        btnTap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count++;  // Increment count
                tvCount.setText("Count: " + count);  // Update the TextView with the new count
            }
        });
    }
}
